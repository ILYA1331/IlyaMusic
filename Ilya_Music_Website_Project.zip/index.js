
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Instagram, Music, Info } from 'lucide-react';
import { motion } from 'framer-motion';

export default function IlyaMusicWebsite() {
    return (
        <div className="min-h-screen bg-black text-white px-8 py-16">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2 }} className="text-center mb-12">
                <h1 className="text-5xl font-bold mb-4">Ilya</h1>
                <p className="text-lg text-gray-400">موسیقی، زندگی، احساس</p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <Card className="bg-gray-900 text-center p-6 rounded-2xl shadow-lg">
                    <Music className="mx-auto mb-4" size={48} />
                    <h2 className="text-2xl font-semibold">موزیک‌ها</h2>
                    <p className="text-gray-400 mb-4">گوش بده و حس کن</p>
                    <Button className="bg-green-500 w-full">پخش موزیک‌ها</Button>
                </Card>

                <Card className="bg-gray-900 text-center p-6 rounded-2xl shadow-lg">
                    <Info className="mx-auto mb-4" size={48} />
                    <h2 className="text-2xl font-semibold">بیوگرافی</h2>
                    <p className="text-gray-400 mb-4">داستان زندگی و مسیر هنری</p>
                    <Button className="bg-blue-500 w-full">بیشتر بخون</Button>
                </Card>

                <Card className="bg-gray-900 text-center p-6 rounded-2xl shadow-lg">
                    <Instagram className="mx-auto mb-4" size={48} />
                    <h2 className="text-2xl font-semibold">صفحات اجتماعی</h2>
                    <p className="text-gray-400 mb-4">اتصال به شبکه‌های اجتماعی</p>
                    <Button className="bg-pink-500 w-full">برو به اینستاگرام</Button>
                </Card>
            </div>
        </div>
    );
}
